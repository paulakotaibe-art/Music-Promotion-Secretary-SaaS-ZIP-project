import "./styles.css";
export const metadata={title:"Music Promotion Secretary",description:"A SaaS app that helps artists promote music with automated campaigns."};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
