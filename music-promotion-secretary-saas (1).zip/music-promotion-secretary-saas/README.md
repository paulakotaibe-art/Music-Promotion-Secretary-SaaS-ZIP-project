# Music Promotion Secretary SaaS

Subscription SaaS for artists to manage songs, Gumroad/Beacons/social links, and generate 7-day music promotion campaigns.

Plans:
- Starter Artist — £5/month — 5 songs
- Growing Artist — £10/month — 20 songs
- Executive Artist — £20/month — 100 songs + video option

Setup:
1. Create Supabase project.
2. Run `supabase/schema.sql` in Supabase SQL editor.
3. Create Stripe monthly prices for £5, £10, £20.
4. Add `.env.example` values into Vercel Environment Variables.
5. Deploy to Vercel.

Do not put secret keys directly into GitHub.
